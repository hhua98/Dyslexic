package com.example.tarik.triggerwordsv1;

/**
 * Created by Tarik on 29-Mar-17.
 */

public class Informationn {

    int iconId;
    String title;
}
